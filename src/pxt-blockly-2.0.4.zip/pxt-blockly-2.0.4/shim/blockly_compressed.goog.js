module.exports = require('./blockly_compressed').goog;
