module.exports = require('imports-loader?goog=./shim/blockly_compressed.goog,Blockly=./shim/blockly_compressed-blocks_compressed!exports-loader?Blockly!../blocks_compressed');
